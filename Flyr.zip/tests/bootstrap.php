<?php

require 'vendor/autoload.php';
require 'Flyr/Config/config.php';
