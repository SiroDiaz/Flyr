<?php

return array(
	'server' => 'PLACE HERE THE SMTP SERVER',
	'port' => 465,
	'email' => 'PLACE YOUR EMAIL HERE',
	'password' => 'PLACE YOUR PASSWORD HERE',
	'charset' => 'UTF-8'
);
