<?php
	
	return array (
		'mon' => 'monday',
		'thu' => 'thuesday',
		'wen' => 'wensday',
		'thur' => 'thursday',
		'fri' => 'friday',
		'sat' => 'saturday',
		'sun' => 'sunday'
	);