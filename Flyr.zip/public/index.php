<?php

/*
 * redirects to the main index.php
 * because sometimes public is the
 * DocumentRoot application deppending
 * of the environment
 */

require __DIR__ .'/../index.php';
